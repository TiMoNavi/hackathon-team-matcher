"use client";
import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Menu, Pause, Play, Radio, Sparkles, X, Orbit, MapPin, Layers, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog,DialogClose,DialogContent,DialogDescription,DialogHeader,DialogTitle } from '@/components/ui/dialog';
import { TiltCard } from '@/components/effects/tilt-card';
import { GridBackground } from '@/components/effects/grid-background';
import { useMotionPreference } from '@/components/motion-preference';
import { FactsField } from '@/components/facts-field';
import { ProfileSections } from '@/components/profile-sections';
import { ViewerInsights } from '@/components/viewer-insights';
import { ProfileStories } from '@/components/profile-stories';
import { identity,visibleEntries,toDetail,type Detail,type Scenario } from '@/lib/profile-data';

type Panel={kind:'contact'}|{kind:'detail';detail:Detail};
const navigation=[{id:'insights',label:'AI 合作参考'},{id:'capabilities',label:'能力与经历'},{id:'commitment',label:'本次投入'},{id:'ideas',label:'想法与活动'}];
export function ProfilePage(){
  const {paused,reduced,toggle}=useMotionPreference();
  const [panel,setPanel]=useState<Panel|null>(null);
  const [activeSection,setActiveSection]=useState('about');
  const [menuOpen,setMenuOpen]=useState(false);
  const [scenario,setScenario]=useState<Scenario>('full');
  const [draft,setDraft]=useState('你好，知夏！看到你在做漫游地图，想聊聊我们可以怎样分工。');
  const [saved,setSaved]=useState(false);
  const lastFocus=useRef<HTMLElement|null>(null);
  const sparse=scenario==='sparse';
  const profile=visibleEntries(sparse);
  const openPanel=(next:Panel)=>{lastFocus.current=document.activeElement as HTMLElement;setPanel(next);setMenuOpen(false);};
  const openDetail=(detail:Detail)=>openPanel({kind:'detail',detail});
  const greet=(message?:string)=>{if(message){setDraft(message);setSaved(false);}openPanel({kind:'contact'});};
  useEffect(()=>{
    const update=()=>{let current='about';for(const item of navigation){const el=document.getElementById(item.id);if(el&&el.getBoundingClientRect().top<=200)current=item.id;}setActiveSection(current);};
    window.addEventListener('scroll',update,{passive:true});return()=>window.removeEventListener('scroll',update);
  },[]);
  return <>
    <a className="skip-link" href="#main">跳到个人主页内容</a>
    <header className="site-header">
      <a href="#about" className="site-brand" aria-label="同频，返回个人主页顶部"><span className="brand-symbol"><Radio size={23}/></span><strong>同频</strong><span className="brand-divider"/><span className="brand-page">个人主页</span></a>
      <nav className="desktop-nav" aria-label="个人主页章节">{navigation.map(item=><a key={item.id} href={'#'+item.id} aria-current={activeSection===item.id?'location':undefined}>{item.label}</a>)}</nav>
      <div className="header-actions"><button className="motion-toggle" onClick={toggle} aria-label={reduced?'系统已减少动态效果':paused?'播放页面动效':'暂停页面动效'} aria-pressed={paused} disabled={reduced}>{paused?<Play size={16}/>:<Pause size={16}/>}</button><Button className="header-contact" onClick={()=>greet()}>打个招呼<ArrowUpRight size={15}/></Button><button className="mobile-menu-toggle" aria-label={menuOpen?'关闭导航':'打开导航'} aria-expanded={menuOpen} aria-controls="mobile-nav" onClick={()=>setMenuOpen(!menuOpen)}>{menuOpen?<X size={21}/>:<Menu size={21}/>}</button></div>
      {menuOpen&&<nav className="mobile-nav" id="mobile-nav" aria-label="手机章节导航" onKeyDown={e=>{if(e.key==='Escape')setMenuOpen(false);}}>{navigation.map(item=><a key={item.id} href={'#'+item.id} onClick={()=>setMenuOpen(false)}>{item.label}<ArrowUpRight size={15}/></a>)}</nav>}
    </header>
    <main id="main">
      <section className="profile-hero" id="about" aria-labelledby="profile-title">
        <div className="hero-atmosphere" aria-hidden="true"><GridBackground className="profile-grid" size={56} speed={0} color="color-mix(in srgb,var(--primary) 6%,transparent)" fade={88} reveal={false}/><div className="hero-glow"/></div>
        <div className="profile-container">
          <div className="hero-breadcrumb"><span>PEOPLE /</span><span>LIN ZHIXIA</span><span className="breadcrumb-end">每个人，都不止一面。<Sparkles size={14}/></span></div>
          <div className="profile-stage">
            <div className="identity-column">
              <TiltCard maxTilt={paused?0:2} scale={1} className="portrait-tilt"><div className="portrait-card">
                {scenario==='no-photo'?<div className="portrait-fallback"><Orbit size={110} strokeWidth={.7}/><span>林</span></div>:<Image src={identity.avatar_ref} alt="虚构人物资料的演示肖像，照片与资料无关" fill sizes="(max-width:767px) 90vw, 390px" priority className="portrait-image"/>}
                <div className="portrait-shade"/>{!sparse&&<span className="portrait-availability"><i/>开放合作</span>}
                <div className="portrait-copy"><span>MEET THE MAKER</span><p>Lin Zhixia<span>.</span></p><span className="portrait-location"><MapPin size={13}/>杭州{!sparse&&' / UTC+8'}</span></div>
                <span className="portrait-mark" aria-hidden="true"><Sparkles size={34} strokeWidth={1}/></span>
              </div></TiltCard>
              <div className="portrait-under"><span className="portrait-line"/><span>一点设计，一点代码。</span><span className="portrait-number">01 / PEOPLE</span></div>
              <div className="person-actions"><Button size="xl" onClick={()=>greet()}>聊聊合作<MessageCircle size={17}/></Button><a className="profile-details-button" href="#capabilities" aria-label="浏览完整资料"><Layers size={19}/></a></div>
            </div>
            <div className="profile-world">
              <div className="world-heading"><div className="world-title-row"><h1 id="profile-title">{scenario==='long'?'林知夏 · 保持好奇的产品设计师':identity.nickname}<span>.</span></h1><span className="profile-scope">个人主页<span>PROFILE / 2026</span></span></div><p>{identity.headline}<span className="heading-divider"/>从几个片段，开始认识。</p></div>
              <FactsField key={sparse?'sparse':'full'} onOpen={entry=>openDetail(toDetail(entry))} dialogOpen={panel!==null} sparse={sparse} long={scenario==='long'}/>
            </div>
          </div>
          <div className="hero-bottom"><a href="#insights"><span className="scroll-cue"><ArrowDown size={15}/></span>看看你们，可以一起做什么</a><span>{profile.length} 条可见资料<span>·</span>演示人物</span></div>
        </div>
      </section>
      <div className="body-container">
        <ViewerInsights entries={profile} sparse={sparse} onOpen={entry=>openDetail(toDetail(entry))} onGreet={greet}/>
        <ProfileSections entries={profile} sparse={sparse} long={scenario==='long'} open={openDetail}/>
        <ProfileStories open={openDetail} sparse={sparse} long={scenario==='long'}/>
        <section className="invitation" aria-labelledby="invitation-title"><div><span className="eyebrow">A CONVERSATION AWAY</span><h2 id="invitation-title">下一件作品，<br/>也许和你一起。</h2><p>从一个共同的问题开始，聊聊各自能做什么。</p></div><div className="invitation-action"><span className="invitation-symbol" aria-hidden="true"><Sparkles size={56} strokeWidth={.8}/></span><Button size="xl" onClick={()=>greet()}>从一句你好开始<ArrowRight size={18}/></Button><span>联系方式由本人单独授权</span></div></section>
      </div>
    </main>
    <footer className="site-footer"><a href="#about" className="footer-brand"><Radio size={20}/>同频<span>让有趣的人，相遇。</span></a><p>独立设计预览 · 人物、资料、关系与 AI 解读均为演示</p><a href="#about" className="back-top">回到顶部<ArrowUpRight size={14}/></a><details className="preview-settings"><summary>预览设置</summary><label htmlFor="scenario">内容状态</label><select id="scenario" value={scenario} onChange={e=>setScenario(e.target.value as Scenario)}><option value="full">完整资料</option><option value="sparse">少量资料 / 无关系</option><option value="long">长姓名与长条目</option><option value="no-photo">尚未上传照片</option></select><span>仅切换本地示例，刷新重置。</span></details></footer>
    <Dialog open={panel!==null} onOpenChange={open=>{if(!open)setPanel(null);}}><DialogContent className="profile-modal" showCloseButton={false} onCloseAutoFocus={e=>{e.preventDefault();lastFocus.current?.focus({preventScroll:true});}}><DialogClose asChild><button className="modal-close" aria-label="关闭详情"><X size={20}/></button></DialogClose>
      {panel?.kind==='detail'&&<><DialogHeader><span className="eyebrow">{panel.detail.eyebrow}</span><DialogTitle>{panel.detail.title}</DialogTitle><DialogDescription>林知夏 · 对当前观看者可见的演示内容</DialogDescription></DialogHeader><div className="dialog-scroll detail-reading"><p>{panel.detail.body}</p>{panel.detail.tags&&<div className="tag-list">{panel.detail.tags.map(tag=><span key={tag}>{tag}</span>)}</div>}</div><div className="modal-note"><Sparkles size={14}/>虚构示例{panel.detail.field&&<span>资料字段 · {panel.detail.field}</span>}</div></>}
      {panel?.kind==='contact'&&<><DialogHeader><span className="eyebrow">START SOMETHING</span><DialogTitle>从一个共同的话题开始。</DialogTitle><DialogDescription>说说你看到的想法，和你能带来的部分。</DialogDescription></DialogHeader><form className="hello-form" onSubmit={e=>{e.preventDefault();if(draft.trim())setSaved(true);}}><div className="hello-recipient"><span className="hello-avatar">林</span><span><strong>林知夏</strong><small>{identity.headline}</small></span></div><label htmlFor="hello-message">你的开场白</label><textarea id="hello-message" value={draft} maxLength={300} rows={4} onChange={e=>{setDraft(e.target.value);setSaved(false);}}/><div className="message-meta"><span>本地草稿，不会发送消息或好友申请。</span><span>{draft.length}/300</span></div><Button type="submit" size="xl" disabled={!draft.trim()||saved}>{saved?<><Check size={17}/>已保存开场白</>:<>保存这句开场白<ArrowRight size={17}/></>}</Button><p role="status" className="hello-status">{saved?'已留在本页，刷新后重置。':''}</p></form></>}
    </DialogContent></Dialog>
  </>;
}

"use client";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { ArrowDown, ArrowRight, ArrowUpRight, Check, ChevronRight, Menu, Pause, Play, Radio, Sparkles, UserRound, X, Heart, Orbit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TiltCard } from "@/components/effects/tilt-card";
import { GradientFloor } from "@/components/effects/gradient-floor";
import { GridBackground } from "@/components/effects/grid-background";
import { useMotionPreference } from "@/components/motion-preference";
import { FactsField } from "@/components/facts-field";
import { Invitation, ProfileStories, type Detail } from "@/components/profile-stories";
import { factSlots, type Fact } from "@/lib/profile-data";

type Panel = { kind: "profile" | "contact" } | { kind: "detail"; detail: Detail };
type Scenario = "full" | "sparse" | "long" | "no-photo";
const navigation = [{ id: "about", label: "关于我" }, { id: "ideas", label: "我的想法" }, { id: "activities", label: "活动足迹" }];

export function ProfilePage() {
  const { paused, reduced, toggle } = useMotionPreference();
  const [panel, setPanel] = useState<Panel | null>(null);
  const [activeSection, setActiveSection] = useState("about");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scenario, setScenario] = useState<Scenario>("full");
  const [draft, setDraft] = useState("你好，知夏！我也对漫游地图很感兴趣，想听听你的想法。");
  const [saved, setSaved] = useState(false);
  const lastFocus = useRef<HTMLElement | null>(null);
  const openPanel = (next: Panel) => { lastFocus.current = document.activeElement as HTMLElement; setPanel(next); setMenuOpen(false); };
  const openDetail = (detail: Detail) => openPanel({ kind: "detail", detail });
  const openFact = (fact: Fact) => openDetail({ eyebrow: fact.label, title: fact.title + (fact.kind === "seeking" ? fact.text : ""), body: fact.detail, tags: fact.tags });
  const sparse = scenario === "sparse";
  const isLong = scenario === "long";
  useEffect(() => {
    const update = () => {
      let current = "about";
      for (const item of navigation) { const el = document.getElementById(item.id); if (el && el.getBoundingClientRect().top <= 190) current = item.id; }
      setActiveSection(current);
    };
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  return <>
    <a className="skip-link" href="#main">跳到个人主页内容</a>
    <header className="site-header">
      <a href="#about" className="site-brand" aria-label="同频，返回个人主页顶部"><span className="brand-symbol"><Radio size={23} strokeWidth={2} /></span><strong>同频</strong><span className="brand-divider" /><span className="brand-page">个人主页</span></a>
      <nav className="desktop-nav" aria-label="个人主页章节">{navigation.map(item => <a key={item.id} href={`#${item.id}`} aria-current={activeSection === item.id ? "location" : undefined}>{item.label}</a>)}</nav>
      <div className="header-actions"><button className="motion-toggle" onClick={toggle} aria-label={reduced ? "系统已减少动态效果" : paused ? "播放页面动效" : "暂停页面动效"} aria-pressed={paused} disabled={reduced} title={paused ? "播放动效" : "暂停动效"}>{paused ? <Play size={16} /> : <Pause size={16} />}</button><Button className="header-contact" onClick={() => openPanel({ kind: "contact" })}>打个招呼<ArrowUpRight size={15} /></Button><button className="mobile-menu-toggle" aria-label={menuOpen ? "关闭导航" : "打开导航"} aria-expanded={menuOpen} aria-controls="mobile-nav" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button></div>
      {menuOpen && <nav className="mobile-nav" id="mobile-nav" aria-label="手机章节导航" onKeyDown={event => { if (event.key === "Escape") setMenuOpen(false); }}>{navigation.map(item => <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)}>{item.label}<ArrowUpRight size={15} /></a>)}</nav>}
    </header>
    <main id="main">
      <section className="profile-hero" id="about" aria-labelledby="profile-title">
        <div className="hero-atmosphere" aria-hidden="true"><GradientFloor className="profile-light" colors={["var(--secondary)", "var(--primary)", "var(--secondary)"]} speed={paused ? 0 : 18} /><GridBackground className="profile-grid" size={56} speed={0} color="color-mix(in srgb, var(--primary) 5%, transparent)" fade={88} reveal={false} /><div className="hero-soft-orb" /></div>
        <div className="profile-container">
          <div className="hero-breadcrumb"><span>PEOPLE</span><ChevronRight size={12} /><span>LIN ZHIXIA</span><span className="breadcrumb-line" /><span className="hello-note">很高兴，在这里遇见你。</span></div>
          <div className="profile-stage">
            <div className="identity-column">
              <div className="portrait-wrap"><TiltCard maxTilt={paused ? 0 : 3} scale={paused ? 1 : 1.012} className="portrait-tilt"><div className="portrait-card">{scenario === "no-photo" ? <div className="portrait-fallback"><Orbit size={98} strokeWidth={.7} /><span>林</span></div> : <Image src="/images/portrait.jpg" alt="个人主页演示肖像，照片人物与虚构资料无关" fill sizes="(max-width: 767px) 90vw, (max-width: 1023px) 34vw, 380px" priority className="portrait-image" />}<div className="portrait-shade" /><span className="portrait-availability"><i />期待一起做点什么</span><div className="portrait-copy"><span>DESIGNER. MAKER. DREAMER.</span><p>永远对新事物心动。</p></div><span className="portrait-mark" aria-hidden="true"><Sparkles size={30} strokeWidth={1.15} /></span></div></TiltCard><span className="portrait-sticker" aria-hidden="true">a curious soul.<ArrowUpRight size={16} /></span></div>
              <div className="identity-caption"><div className="identity-name-row"><h2>{isLong ? "林知夏 · 一个始终保持好奇的人" : "林知夏"}<span className="name-dot">.</span></h2><span className="identity-pronouns">she / her</span></div><p>产品设计师<span> / </span>创意前端</p><span className="identity-english">BASED IN HANGZHOU · OPEN TO COLLAB</span></div>
              <div className="person-actions"><Button size="xl" onClick={() => openPanel({ kind: "contact" })}>一起做点什么<ArrowUpRight size={17} /></Button><button className="profile-details-button" onClick={() => openPanel({ kind: "profile" })} aria-label="查看完整资料"><UserRound size={19} /></button></div>
            </div>
            <div className="profile-world"><div className="world-heading"><span className="world-eyebrow"><span className="tiny-star"><Sparkles size={13} /></span> A LITTLE ABOUT ME</span><h1 id="profile-title">把<span className="curiosity-word">好奇心</span>，<br />做成点什么<span className="title-period">。</span></h1><p>{isLong ? "喜欢把生活里那些看似微小、却值得认真对待的问题，变成每个人都能轻松使用的产品。设计、开发和人与人之间的交流，都让我保持好奇。" : "喜欢设计，也喜欢动手。正在寻找一起把想法变成现实的人。"}</p></div><FactsField onOpen={openFact} dialogOpen={panel !== null} sparse={sparse} /></div>
          </div>
          <div className="hero-bottom"><a href="#ideas"><span className="scroll-cue"><ArrowDown size={15} /></span>往下看看，想法会继续生长。</a><button className="text-link" onClick={() => openPanel({ kind: "profile" })}>认识更多面的我<ArrowUpRight size={15} /></button></div>
        </div>
      </section>
      <div className="body-container"><ProfileStories open={openDetail} sparse={sparse} long={isLong} /><Invitation onContact={() => openPanel({ kind: "contact" })} /></div>
    </main>
    <footer className="site-footer"><a href="#about" className="footer-brand"><Radio size={19} />同频<span>让有趣的人，相遇。</span></a><p>独立预览 · 人物、资料与活动均为演示</p><a href="#about" className="back-top">回到顶部<ArrowUpRight size={14} /></a><details className="preview-settings"><summary>预览设置</summary><label htmlFor="scenario">内容状态</label><select id="scenario" value={scenario} onChange={event => setScenario(event.target.value as Scenario)}><option value="full">完整资料</option><option value="sparse">资料较少 / 无想法活动</option><option value="long">长姓名与长文案</option><option value="no-photo">尚未上传照片</option></select><span>仅切换本地演示内容，刷新会重置。</span></details></footer>
    <Dialog open={panel !== null} onOpenChange={open => { if (!open) setPanel(null); }}>
      <DialogContent className="profile-modal" showCloseButton={false} onCloseAutoFocus={event => { event.preventDefault(); lastFocus.current?.focus({ preventScroll: true }); }}>
        <DialogClose asChild><button className="modal-close" aria-label="关闭详情"><X size={20} /></button></DialogClose>
        {panel?.kind === "detail" && <><DialogHeader><span className="eyebrow">{panel.detail.eyebrow}</span><DialogTitle>{panel.detail.title}</DialogTitle><DialogDescription>知夏的一个小片段</DialogDescription></DialogHeader><div className="dialog-scroll detail-reading"><p>{panel.detail.body}</p>{panel.detail.tags && <div className="tag-list">{panel.detail.tags.map(tag => <span key={tag}>{tag}</span>)}</div>}</div><div className="modal-note"><Sparkles size={14} />演示内容，仅用于体验个人主页。</div></>}
        {panel?.kind === "profile" && <><DialogHeader><span className="eyebrow">GET TO KNOW ME</span><DialogTitle>关于林知夏</DialogTitle><DialogDescription>产品设计 / 创意前端 · 杭州</DialogDescription></DialogHeader><div className="dialog-scroll full-profile"><p className="profile-bio">我喜欢把模糊的想法做成看得见、摸得着的东西。做设计，也写一点代码；愿意从小问题开始，和认真又有趣的人一起试试看。</p>{factSlots.slice(0, sparse ? 2 : 6).map(([fact]) => <section key={fact.id}><h3>{fact.label}</h3><p>{fact.detail}</p>{fact.tags && <div className="tag-list">{fact.tags.map(tag => <span key={tag}>{tag}</span>)}</div>}</section>)}</div><div className="modal-note">资料为虚构演示，不对应照片人物的真实经历。</div></>}
        {panel?.kind === "contact" && <><DialogHeader><span className="eyebrow">A GOOD PLACE TO START</span><DialogTitle>先说一句你好。</DialogTitle><DialogDescription>提一个共同感兴趣的点，让相识自然一点。</DialogDescription></DialogHeader><form className="hello-form" onSubmit={event => { event.preventDefault(); if (draft.trim()) setSaved(true); }}><div className="hello-recipient"><Image src="/images/portrait.jpg" width={44} height={44} alt="" /><span><strong>林知夏</strong><small>也许，正好有一个共同的想法。</small></span><Heart size={18} /></div><label htmlFor="hello-message">你的开场白</label><textarea id="hello-message" value={draft} maxLength={300} rows={4} onChange={event => { setDraft(event.target.value); setSaved(false); }} /><div className="message-meta"><span>本地演示，不会发送消息或好友申请。</span><span>{draft.length}/300</span></div><Button type="submit" size="xl" disabled={!draft.trim() || saved}>{saved ? <><Check size={17} />已保存开场白</> : <>保存这句开场白<ArrowRight size={17} /></>}</Button><p role="status" className="hello-status">{saved ? "这句话已留在本页。实际发送将在正式接入后提供。" : ""}</p></form></>}
      </DialogContent>
    </Dialog>
  </>;
}

"use client";
import { useEffect, useLayoutEffect, useRef, useState, useSyncExternalStore } from "react";
import { ArrowUpRight, Code2, Compass, MapPin, MessageCircle, Sparkles, WandSparkles, RotateCw } from "lucide-react";
import { BlurCrossfade } from "@/components/effects/blur-crossfade";
import { SceneMotion, useMotionPreference } from "@/components/motion-preference";
import { factSlots, type Fact } from "@/lib/profile-data";

const icons = { skills: Code2, place: MapPin, project: Compass, style: MessageCircle, seeking: WandSparkles, interest: Sparkles };
function subscribeCompact(callback: () => void) { const mq = matchMedia("(max-width: 767px)"); mq.addEventListener("change", callback); return () => mq.removeEventListener("change", callback); }
function subscribeVisibility(callback: () => void) { document.addEventListener("visibilitychange", callback); return () => document.removeEventListener("visibilitychange", callback); }

function FactCard({ fact, onOpen, index }: { fact: Fact; onOpen: (fact: Fact) => void; index: number }) {
  const Icon = icons[fact.kind];
  return <button className={`fact-card fact-card--${fact.kind}`} onClick={() => onOpen(fact)} data-slot={index} aria-label={`了解${fact.label}：${fact.title}${fact.kind === "seeking" ? fact.text : ""}`}>
    <BlurCrossfade id={fact.id} morph="none" blur={3} duration={600}>
      <span className="fact-label"><Icon size={14} strokeWidth={1.7} /><span>{fact.label}</span><ArrowUpRight className="fact-arrow" size={14} /></span>
      <span className="fact-title">{fact.title}</span>
      <span className="fact-description">{fact.text}</span>
      {fact.tags && <span className="fact-tags">{fact.tags.map(tag => <span key={tag}>{tag}</span>)}</span>}
    </BlurCrossfade>
  </button>;
}

/** The measured/pauseable loop approach comes from Kit hero14 via the homepage.
 * Here six bounded grid slots replace an infinite strip: the user's card-reading
 * requirement takes priority. Tracks have separate transform space and never collide. */
export function FactsField({ onOpen, dialogOpen, sparse = false }: { onOpen: (fact: Fact) => void; dialogOpen: boolean; sparse?: boolean }) {
  const { paused } = useMotionPreference();
  const compact = useSyncExternalStore(subscribeCompact, () => matchMedia("(max-width: 767px)").matches, () => false);
  const visible = useSyncExternalStore(subscribeVisibility, () => !document.hidden, () => true);
  const [versions, setVersions] = useState([0, 0, 0, 0, 0, 0]);
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [inView, setInView] = useState(true);
  const root = useRef<HTMLDivElement>(null);
  const cursor = useRef(0);
  const stopped = paused || compact || hovered || focused || dialogOpen || !inView || !visible || sparse;
  const playbacks = useRef<Animation[]>([]);
  const motionStopped = useRef(stopped);
  useLayoutEffect(() => {
    motionStopped.current = stopped;
    for (const animation of playbacks.current) {
      if (stopped) {
        const position = animation.currentTime;
        animation.pause();
        if (position !== null) animation.currentTime = position;
      } else animation.play();
    }
  }, [stopped]);
  useEffect(() => {
    if (compact || sparse || !root.current) return;
    const durations = [18000, 22000, 20000];
    const phases = [6000, 13000, 10000];
    const animations = Array.from(root.current.querySelectorAll<HTMLElement>(".fact-track")).map((track, index) => {
      const animation = track.animate([{ transform: "translate3d(-5px,0,0)" }, { transform: "translate3d(13px,0,0)" }], { duration: durations[index], iterations: Infinity, direction: "alternate", easing: "ease-in-out" });
      animation.currentTime = phases[index];
      if (motionStopped.current) { animation.pause(); animation.currentTime = phases[index]; }
      return animation;
    });
    playbacks.current = animations;
    return () => { animations.forEach(animation => animation.cancel()); playbacks.current = []; };
  }, [compact, sparse]);
  useEffect(() => {
    if (!root.current) return;
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { threshold: .1 });
    observer.observe(root.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (stopped) return;
    const timer = window.setInterval(() => {
      const slot = [4, 1, 3, 0, 5, 2][cursor.current++ % 6];
      setVersions(current => current.map((version, index) => index === slot ? version + 1 : version));
    }, 9000);
    return () => window.clearInterval(timer);
  }, [stopped]);
  const facts = factSlots.map((options, index) => options[versions[index] % options.length]);
  return <div className="facts-wrap">
    <div className="facts-field" ref={root} data-paused={stopped} data-sparse={sparse} data-testid="facts-field" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} onFocusCapture={() => setFocused(true)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false); }}>
      <svg className="fan-paths" viewBox="0 0 760 470" preserveAspectRatio="none" aria-hidden="true"><path d="M-100 220 C150 235 310 25 760 30" /><path d="M-100 220 C190 200 380 210 760 224" /><path d="M-100 220 C180 240 350 435 760 454" /><circle cx="727" cy="30" r="4" /><circle cx="706" cy="449" r="3" /></svg>
      <SceneMotion active={!stopped}>
        {[0, 1, 2].map(row => <div className={`fact-row fact-row-${row}`} key={row}><div className="fact-track">{[row * 2, row * 2 + 1].map(index => (!sparse || index < 2) && <FactCard key={index} fact={facts[index]} index={index} onOpen={onOpen} />)}</div></div>)}
      </SceneMotion>
      <span className="field-spark field-spark-one" aria-hidden="true"><Sparkles size={22} strokeWidth={1.25} /></span>
      <span className="field-dot" aria-hidden="true" />
    </div>
    <div className="field-caption"><span><span className="caption-dot" />{sparse ? "留一点空白，慢慢认识" : compact ? "关于我的一些小片段" : hovered || focused ? "停一停，慢慢看" : "一些关于我的碎片，慢慢看"}</span><button className="shuffle-facts" onClick={() => setVersions(current => current.map(x => x + 1))}><RotateCw size={13} />换一组</button></div>
  </div>;
}

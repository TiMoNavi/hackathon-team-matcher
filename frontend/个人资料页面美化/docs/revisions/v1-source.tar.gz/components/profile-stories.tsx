"use client";
import { useState } from "react";
import Image from "next/image";
import { ArrowUpRight, Bookmark, Check, Compass, MapPin, Sparkles, CalendarDays, ArrowRight, Coffee, Leaf, Navigation, Lightbulb, PenTool } from "lucide-react";
import { activities, ideas } from "@/lib/profile-data";
export type Detail = { eyebrow: string; title: string; body: string; tags?: string[] };

export function IdeaArtwork({ type }: { type: string }) {
  if (type === "roam") return <div className="idea-art map-art" aria-hidden="true"><div className="map-streets" /><div className="map-park park-one" /><div className="map-park park-two" /><div className="map-water" /><svg className="map-route" viewBox="0 0 600 270"><path d="M100 200 C130 195 155 195 175 170 S190 120 240 118 S330 140 370 100 S405 75 465 64" /></svg><span className="map-pin pin-one"><Coffee size={16} /></span><span className="map-pin pin-two"><Leaf size={15} /></span><span className="map-pin pin-three"><MapPin size={17} /></span><span className="map-note"><Navigation size={15} />下个转角，有点期待。</span><span className="map-brand">roam<span>漫游地图</span></span><span className="map-direction">N <ArrowUpRight size={17} /></span></div>;
  return <div className="idea-art spark-art" aria-hidden="true"><div className="spark-halo" /><span className="note-card note-back"><PenTool size={15} /><span>一个还没成形的想法</span><i /><i /></span><span className="note-card note-front"><Lightbulb size={22} /><strong>刚才那个想法，<br />我记住了。</strong><span className="note-foot">留住每一次灵光一闪<ArrowUpRight size={14} /></span></span><Sparkles className="note-spark" size={26} strokeWidth={1.3} /><span className="spark-word">a little spark.</span></div>;
}

export function ProfileStories({ open, sparse, long }: { open: (detail: Detail) => void; sparse: boolean; long: boolean }) {
  const [saved, setSaved] = useState<string[]>([]);
  const [filter, setFilter] = useState<"all" | "ongoing" | "past">("all");
  const visibleEvents = sparse ? [] : activities.filter(item => filter === "all" || item.status === filter);
  return <>
    <section id="ideas" className="content-section ideas-section" aria-labelledby="ideas-title">
      <div className="section-heading-row"><div><span className="eyebrow"><span>01</span> IDEAS & LITTLE EXPERIMENTS</span><h2 id="ideas-title">一些念头，<span className="soft-word">正在发芽。</span></h2></div><p>想做的事很多，<br />先从一件有趣的小事开始。</p></div>
      {sparse ? <div className="empty-content"><Lightbulb size={28} strokeWidth={1.3} /><h3>好想法，也需要一点时间。</h3><p>这里暂时没有可展示的想法，先从认识彼此开始。</p></div> : <div className="ideas-grid">{ideas.map((idea, index) => <article className={`idea-card idea-card-${idea.accent}`} key={idea.id}>
        <div className="idea-cover"><IdeaArtwork type={idea.accent} /><button className={`save-idea ${saved.includes(idea.id) ? "is-saved" : ""}`} aria-label={`${saved.includes(idea.id) ? "取消收藏" : "收藏"}${idea.name}`} aria-pressed={saved.includes(idea.id)} onClick={() => setSaved(current => current.includes(idea.id) ? current.filter(id => id !== idea.id) : [...current, idea.id])}>{saved.includes(idea.id) ? <Check size={18} /> : <Bookmark size={18} />}</button><span className="idea-art-label">{idea.category}</span></div>
        <div className="idea-body"><div className="idea-meta"><span>想法 / 0{index + 1}</span><span className="idea-status"><i />{index === 0 ? "想找人一起做" : "慢慢打磨中"}</span></div><h3>{long && index === 0 ? "把旅行中每一个值得珍藏的小小发现，做成真正能出发的路线" : idea.name}</h3><p>{idea.description}</p><div className="idea-bottom"><div className="tag-list">{idea.tags.map(tag => <span key={tag}>{tag}</span>)}</div><button className="round-link" aria-label={`展开想法：${idea.name}`} onClick={() => open({ eyebrow: `我的想法 · ${idea.event}`, title: idea.name, body: idea.detail, tags: idea.tags })}><ArrowUpRight size={20} /></button></div></div>
      </article>)}</div>}
      <p className="section-footnote"><Sparkles size={13} />想法可以很小，有人一起就很好。<span role="status">{saved.length > 0 ? `已在本页收藏 ${saved.length} 个想法` : ""}</span></p>
    </section>
    <section id="activities" className="content-section activities-section" aria-labelledby="activities-title">
      <div className="section-heading-row"><div><span className="eyebrow"><span>02</span> OUT THERE, MAKING THINGS</span><h2 id="activities-title">在场，<span className="soft-word">也在生长。</span></h2></div><div className="event-filters" role="group" aria-label="筛选活动">{([{ key: "all", label: "全部" }, { key: "ongoing", label: "正在参加" }, { key: "past", label: "过去的活动" }] as const).map(item => <button key={item.key} aria-pressed={filter === item.key} onClick={() => setFilter(item.key)}>{item.label}</button>)}</div></div>
      <div className="events-grid" data-count={visibleEvents.length}>{visibleEvents.length ? visibleEvents.map(event => <article className={`event-card ${event.status === "ongoing" ? "event-current" : ""}`} key={event.id}>
        <div className="event-top"><span className="event-date">{event.shortDate}</span>{event.status === "ongoing" ? <span className="event-live"><i />正在发生</span> : <span className="event-finished"><Check size={12} />已结束</span>}</div>
        <div className="event-symbol" aria-hidden="true">{event.status === "ongoing" ? <Sparkles size={31} strokeWidth={1.2} /> : event.id === "aidesign" ? <PenTool size={26} strokeWidth={1.3} /> : <Coffee size={26} strokeWidth={1.3} />}</div><h3>{event.title}</h3><p>{event.subtitle}</p>
        <div className="event-detail-lines"><span><CalendarDays size={14} />{event.date}</span><span><MapPin size={14} />{event.place}</span></div>
        <div className="event-bottom"><span>{event.role}</span><button className="round-link" aria-label={`查看活动：${event.title}`} onClick={() => open({ eyebrow: `${event.status === "ongoing" ? "正在参加" : "活动经历"} · ${event.date}`, title: event.title, body: event.detail, tags: [event.place, event.role] })}><ArrowUpRight size={19} /></button></div>
      </article>) : <div className="empty-content"><Compass size={28} strokeWidth={1.3} /><h3>下一段故事，还没开始。</h3><p>暂时没有可展示的活动经历。</p></div>}</div>
    </section>
  </>;
}

export function Invitation({ onContact }: { onContact: () => void }) {
  return <section className="invitation" aria-labelledby="invitation-title"><div className="invitation-orbit" aria-hidden="true"><span /><span /><Image src="/avatars/avatar-3.jpg" alt="" width={50} height={50} /><Image src="/avatars/avatar-1.jpg" alt="" width={42} height={42} /><Sparkles size={27} /></div><div className="invitation-copy"><span className="eyebrow">GOOD THINGS START WITH A HELLO</span><h2 id="invitation-title">下一件有趣的事，<br />也许和你一起。</h2><p>带上你的点子，或者，只是来打个招呼。</p><button className="invite-button" onClick={onContact}>从一句「你好」开始<ArrowRight size={18} /></button></div></section>;
}

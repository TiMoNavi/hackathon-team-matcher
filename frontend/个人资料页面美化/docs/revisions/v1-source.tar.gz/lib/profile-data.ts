// Fictional, local-only demo data. No account, backend, or AI calls.
export type Fact = { id: string; label: string; title: string; text: string; tags?: string[]; kind: "skills" | "place" | "project" | "style" | "seeking" | "interest"; detail: string };
export const factSlots: Fact[][] = [
  [
    { id: "skills", label: "我擅长的", title: "从点子，到可用的界面", text: "设计与代码，都愿意再多走一步。", tags: ["Figma", "React", "交互设计"], kind: "skills", detail: "我的主要工作是产品与交互设计，也会用 React 做可交互原型。我喜欢从真实问题开始，先把一条完整的用户路径做通，再慢慢打磨那些让人觉得舒服的小细节。" },
    { id: "making", label: "最近在学", title: "给交互加一点生命力", text: "把一个恰到好处的反馈做细。", tags: ["微交互", "React", "原型"], kind: "skills", detail: "最近在练习用更少的动画表达状态变化，让等待、确认和切换变得清晰。希望和前端伙伴一起，把这些细节带进一个真实的小产品。" },
  ],
  [
    { id: "city", label: "生活坐标", title: "生活在杭州", text: "线下见面，或在线相遇", kind: "place", detail: "常驻杭州，习惯使用中文沟通，也可以阅读英文资料。线下讨论和远程异步协作都可以；具体投入时间会按活动单独约定。" },
    { id: "weekend", label: "周末的我", title: "收集城市日常", text: "咖啡、散步和一些新发现", kind: "place", detail: "我喜欢在城市里散步，拍一些日常的小角落。有时候，一个路牌、一张菜单，也会变成下个设计的起点。" },
  ],
  [
    { id: "project", label: "做过的小作品", title: "把旅行灵感，装进地图", text: "从收藏夹到真正出发的那一步。", tags: ["产品设计", "交互原型"], kind: "project", detail: "「漫游地图」是一个演示项目：把零散收藏的地点放到同一张地图上，按距离和空闲时间组织成一条可以出发的路线。我负责问题梳理、界面设计与交互原型。" },
    { id: "experiment", label: "一个小实验", title: "给零散灵感，找个去处", text: "记下来，再和愿意的人一起做。", tags: ["信息整理", "创意工具"], kind: "project", detail: "我试着把笔记、语音和截图放进一个简单的灵感盒子。重点是让记录足够轻，让回看时能重新找到当时的想法。这是演示项目，没有已上线产品链接。" },
  ],
  [
    { id: "style", label: "相处说明", title: "慢热，点子很多", text: "先认真听，再一起动手。", kind: "style", detail: "比起长时间争论哪种方案最好，我更喜欢先做一个小版本，让大家看见同一个东西。遇到分歧会把理由写下来，也欢迎伙伴直接指出问题。" },
    { id: "working", label: "我的工作方式", title: "先做出来，再做好", text: "小步试验，及时反馈。", kind: "style", detail: "我喜欢把大事拆成当天能推进的小步骤。合作中会同步进度、说明卡住的地方，也给队友留出独立思考的时间。" },
  ],
  [
    { id: "seeking", label: "想遇见这样的你", title: "你让它跑起来，", text: "我让它好用起来。", kind: "seeking", detail: "希望遇到愿意一起讨论问题、也愿意动手的开发伙伴。我可以负责产品与界面设计，希望你把技术上的可能性讲给我听。先用一个小作品看看我们是否合拍。" },
    { id: "goal", label: "这次想一起做", title: "一个周末，", text: "一起做出第一版。", kind: "seeking", detail: "在「周末造物场」这项演示活动里，我希望把一个具体的小问题做成可体验的原型。当前需要创意前端或全栈伙伴；这个目标只属于这次活动。" },
  ],
  [
    { id: "interest", label: "保持好奇", title: "AI、独立产品，还有远方", text: "好用的工具，值得走的路。", tags: ["AI × 设计", "城市漫游"], kind: "interest", detail: "关注 AI 如何帮助人完成日常的小事，也喜欢有个人表达的独立产品。工作之外，散步、摄影和陌生城市里的小店都让我保持好奇。" },
    { id: "values", label: "在意的小事", title: "认真做，也尽兴玩", text: "好的合作，留下一点回忆。", tags: ["开放交流", "一起成长"], kind: "interest", detail: "希望一起工作的过程是轻松而认真的。可以对作品要求很高，也可以在遇到难题时坦诚说一句「我还不会，我们试试看」。" },
  ],
];
export const ideas = [
  { id: "roam", title: "让每一次出发，都有一点意外。", name: "漫游地图", category: "城市探索 × AI", description: "把收藏夹里「有空再去」的地方，变成这个周末的一条小路线。", detail: "我们总是收藏很多地方，却很少真正出发。我想做一张能理解时间、距离和兴趣的地图，帮你从想去的清单里找出今天刚好能走的一条路。第一版只做一座城市和一条完整路径。", tags: ["产品构想", "寻找共创伙伴"], accent: "roam", event: "周末造物场" },
  { id: "spark", title: "灵感闪过的时候，先接住它。", name: "一闪 · 灵感收集", category: "创意工具", description: "让散落的截图、短句和声音，慢慢长成一个想法。", detail: "不用一开始就整理分类，只要轻轻记下一句话。等到你想回看的时候，再把相关线索放在一起。希望做一个真正愿意每天打开的小工具。", tags: ["交互实验", "想法整理"], accent: "spark", event: "周末造物场" },
];
export const activities = [
  { id: "weekend", title: "周末造物场", subtitle: "把「要不试试」变成「真的做了」。", status: "ongoing" as const, date: "2026.11.10 — 11.16", shortDate: "NOV 2026", place: "杭州 · 线上线下", role: "产品设计 / 创意前端", detail: "演示活动：围绕一个日常问题组成小队，完成一个能实际体验的作品。这次我想把漫游地图做成第一版，正在梳理路线选择与地点收藏的交互。" },
  { id: "aidesign", title: "AI × Design 共创日", subtitle: "一起探索设计工具的新可能。", status: "past" as const, date: "2026.10.18", shortDate: "OCT 2026", place: "上海", role: "交互设计", detail: "演示经历：与伙伴讨论 AI 工具如何融入创作过程，完成了灵感收集工具的交互原型。我负责场景梳理和关键页面设计。" },
  { id: "summer", title: "夏日独立开发者聚会", subtitle: "带着半成品，也可以来见面。", status: "past" as const, date: "2026.08.23", shortDate: "AUG 2026", place: "杭州", role: "分享与交流", detail: "演示经历：分享了一个尚未完成的小项目，收到了关于信息结构和使用门槛的反馈。最喜欢的环节是每个人用三分钟讲自己正在解决的一个问题。" },
];

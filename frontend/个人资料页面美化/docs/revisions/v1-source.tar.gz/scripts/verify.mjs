import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = process.cwd();
const out = path.join(root, 'docs/screenshots');
await mkdir(out, { recursive:true });
const browser = await chromium.launch({ headless:true, ...(process.env.CHROMIUM_EXECUTABLE ? { executablePath:process.env.CHROMIUM_EXECUTABLE } : {}) });
const context = await browser.newContext({ viewport:{ width:1440,height:1050 }, deviceScaleFactor:1, recordVideo:process.env.RECORD_VIDEO ? { dir:path.join(root,'docs/video'),size:{width:1440,height:1050} } : undefined });
const page = await context.newPage();
const errors = [], requests = [], checks = [], frames = [];
page.on('pageerror',error=>errors.push(error.message));
page.on('request',request=>{ if(!request.url().startsWith('http://127.0.0.1:') && !request.url().startsWith('data:'))requests.push(request.url()); });
const geometry = () => {
  const cards=[...document.querySelectorAll('.fact-card')].filter(el=>el.getClientRects().length);
  const boxes=cards.map(el=>({id:el.getAttribute('data-slot'),rect:el.getBoundingClientRect().toJSON(),text:(el.querySelector('.ui-bx__layer:not(.ui-bx__layer--out)')||el).innerText}));
  const collisions=[];
  boxes.forEach((a,i)=>boxes.slice(i+1).forEach(b=>{ const x=Math.min(a.rect.right,b.rect.right)-Math.max(a.rect.left,b.rect.left),y=Math.min(a.rect.bottom,b.rect.bottom)-Math.max(a.rect.top,b.rect.top);if(x>1&&y>1)collisions.push([a.id,b.id]); }));
  const clipped=cards.filter(card=>{const content=card.querySelector('.ui-bx__layer:not(.ui-bx__layer--out)');return card.scrollHeight>card.clientHeight+3 || (content && content.getBoundingClientRect().bottom>card.getBoundingClientRect().bottom-7);}).map(c=>c.dataset.slot);
  return { width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,collisions,clipped,boxes };
};
function checkGeometry(result,label) { assert.equal(result.overflow,false,label+' page overflow'); assert.deepEqual(result.collisions,[],label+' overlapping cards'); assert.deepEqual(result.clipped,[],label+' clipped card content'); }
try {
  await page.goto(process.env.PREVIEW_URL||'http://127.0.0.1:4213/',{waitUntil:'networkidle'});
  await page.evaluate(()=>document.fonts.ready);
  await page.getByRole('button',{name:'暂停页面动效',exact:true}).click();
  await page.mouse.move(1430,10);
  for(const [width,height] of [[1440,1050],[1100,950],[1024,950],[901,950],[768,1024],[390,844],[320,800]]) {
    await page.setViewportSize({width,height});
    await page.evaluate(()=>window.scrollTo(0,0));
    const state=await page.evaluate(geometry);checkGeometry(state,String(width));
    checks.push({viewport:width,cards:state.boxes.length,overflow:state.overflow,collisions:state.collisions,clipped:state.clipped});
    if([1440,768,390,320].includes(width)){await page.screenshot({path:path.join(out,`${width}-hero.png`)});await page.screenshot({path:path.join(out,`${width}-full.png`),fullPage:true});}
  }
  await page.setViewportSize({width:1440,height:1050});
  const card=page.locator('.fact-card').first();
  await card.click();await page.getByRole('dialog').waitFor();
  assert.equal(await page.getByRole('dialog').getByRole('heading').count(),1);
  await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});assert.equal(await page.getByRole('dialog').count(),0);
  assert.equal(await card.evaluate(el=>document.activeElement===el),true,'focus returns to clicked card');
  checks.push({detailDialog:true,escapeClose:true,focusRestored:true});
  await page.getByRole('button',{name:'换一组',exact:true}).click();
  checkGeometry(await page.evaluate(geometry),'alternate content');
  assert.match(await card.innerText(),/给交互加一点生命力/);
  await page.getByRole('button',{name:'收藏漫游地图',exact:true}).click();
  assert.equal(await page.getByRole('button',{name:'取消收藏漫游地图',exact:true}).getAttribute('aria-pressed'),'true');
  await page.getByRole('button',{name:'展开想法：漫游地图'}).click();await page.getByRole('dialog').waitFor();await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'正在参加',exact:true}).click();assert.equal(await page.locator('.event-card').count(),1);
  await page.getByRole('button',{name:'过去的活动',exact:true}).click();assert.equal(await page.locator('.event-card').count(),2);
  await page.getByRole('button',{name:'全部',exact:true}).click();assert.equal(await page.locator('.event-card').count(),3);
  await page.getByRole('button',{name:'查看活动：周末造物场'}).click();await page.getByRole('dialog').waitFor();await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});
  checks.push({bookmark:true,ideaDetails:true,activityFilterCounts:[1,2,3],activityDetails:true});
  await page.getByRole('button',{name:'打个招呼',exact:true}).click();
  await page.locator('#hello-message').fill('你好，想和你一起做个有趣的小产品。');
  await page.getByRole('button',{name:'保存这句开场白'}).click();
  assert.equal(await page.getByRole('button',{name:'已保存开场白'}).isDisabled(),true);
  await page.screenshot({path:path.join(out,'1440-contact.png')});await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});
  checks.push({localGreeting:true,noMessageSent:true});
  await page.locator('.preview-settings summary').click();
  for(const scenario of ['sparse','long','no-photo']){
    await page.locator('#scenario').selectOption(scenario);
    for(const width of [1440,390,320]){await page.setViewportSize({width,height:900});await page.evaluate(()=>window.scrollTo(0,0));checkGeometry(await page.evaluate(geometry),scenario+' '+width);}
    if(scenario==='sparse')assert.equal(await page.locator('.empty-content').count(),2);
    await page.screenshot({path:path.join(out,`320-${scenario}.png`),fullPage:true});
  }
  checks.push({contentStates:['sparse','long','no-photo'],stateWidths:[1440,390,320]});
  await page.locator('#scenario').selectOption('full');
  await page.setViewportSize({width:390,height:844});
  await page.evaluate(()=>window.scrollTo(0,0));
  await page.getByRole('button',{name:'打开导航'}).click();await page.getByRole('navigation',{name:'手机章节导航'}).getByRole('link',{name:'我的想法'}).click();
  assert.equal(await page.locator('#mobile-nav').count(),0);
  await page.getByRole('button',{name:'展开想法：漫游地图'}).click();await page.getByRole('dialog').waitFor();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  await page.screenshot({path:path.join(out,'390-detail.png')});await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});
  checks.push({mobileNavigation:true,mobileDialog:true});
  await page.setViewportSize({width:1440,height:1050});await page.evaluate(()=>window.scrollTo(0,0));
  await page.emulateMedia({reducedMotion:'reduce'});
  assert.equal(await page.getByRole('button',{name:'系统已减少动态效果'}).isDisabled(),true);
  assert.equal(await page.locator('.fact-track').first().evaluate(el=>getComputedStyle(el).animationName),'none');
  checks.push({reducedMotion:true});
  await page.emulateMedia({reducedMotion:'no-preference'});
  // Verify actual platform fonts, including Chinese fallback, with CDP.
  const cdp=await context.newCDPSession(page);await cdp.send('DOM.enable');await cdp.send('CSS.enable');
  const {root:dom}=await cdp.send('DOM.getDocument');const fonts={};
  for(const selector of ['.world-heading h1','.fact-title','.world-eyebrow','.portrait-sticker']){const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:dom.nodeId,selector});fonts[selector]=(await cdp.send('CSS.getPlatformFontsForNode',{nodeId})).fonts;}
  checks.push({platformFonts:fonts});
  // Readable pauses and a full 54-second staggered replacement cycle.
  await page.getByRole('button',{name:'播放页面动效',exact:true}).click();
  await page.mouse.move(1430,10);await page.getByRole('heading',{level:1}).click();
  const texts=new Set();
  for(let second=0;second<56;second++){await page.waitForTimeout(1000);const state=await page.evaluate(geometry);checkGeometry(state,'motion '+second);state.boxes.forEach(b=>texts.add(b.text));frames.push({second,positions:state.boxes.map(b=>({id:b.id,x:b.rect.x,y:b.rect.y})),collisions:state.collisions});}
  assert.ok(texts.size>=12,'each slot must show both variants during one cycle');
  const movingTrack=page.locator('.fact-track').first();
  const horizontalPositions=frames.map(frame=>frame.positions[0].x);assert.ok(Math.max(...horizontalPositions)-Math.min(...horizontalPositions)>10,'track visibly travels through bounded range');assert.ok(new Set(horizontalPositions.map(x=>x.toFixed(2))).size>20,'motion runs across the full cycle');
  const hoverBox=await card.boundingBox();await page.mouse.move(hoverBox.x+hoverBox.width/2,hoverBox.y+hoverBox.height/2);await page.waitForFunction(()=>document.querySelector('.facts-field')?.dataset.paused==='true' && document.querySelector('.fact-track')?.getAnimations().every(animation=>animation.playState==='paused' && !animation.pending));const hovered=await movingTrack.evaluate(el=>getComputedStyle(el).transform);await page.waitForTimeout(500);assert.equal(await movingTrack.evaluate(el=>getComputedStyle(el).transform),hovered,'hover pause');
  await page.mouse.move(1430,10);await card.focus();await page.waitForFunction(()=>document.querySelector('.facts-field')?.dataset.paused==='true');assert.equal(await page.locator('.facts-field').getAttribute('data-paused'),'true','keyboard pause');
  await page.getByRole('heading',{level:1}).click();
  await page.locator('#activities').scrollIntoViewIfNeeded();await page.waitForFunction(()=>document.querySelector('.facts-field')?.dataset.paused==='true');assert.equal(await page.locator('.facts-field').getAttribute('data-paused'),'true','offscreen pause');
  checks.push({motionCycleSeconds:56,distinctCardContents:texts.size,hoverPause:true,keyboardPause:true,offscreenPause:true});
  assert.deepEqual(errors,[],'browser runtime errors');assert.deepEqual(requests,[],'unexpected external requests');
  await writeFile(path.join(root,'docs/verification.json'),JSON.stringify({date:'2026-11-12',checks,errors,externalRequests:requests,motionFrames:frames},null,2));
  console.log(JSON.stringify({passed:true,checks:checks.length,errors,externalRequests:requests},null,2));
} catch(error) { await writeFile(path.join(root,'docs/verification-failure.json'),JSON.stringify({error:String(error),checks,errors,frames},null,2));await page.screenshot({path:path.join(out,'failure.png'),fullPage:true});throw error; } finally { await context.close();await browser.close(); }
